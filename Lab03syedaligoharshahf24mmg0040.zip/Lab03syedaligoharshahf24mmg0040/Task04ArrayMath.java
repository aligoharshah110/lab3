public class Task04ArrayMath {
    public static void main(String[] args) {
        int[] arr = new int[10];

        // a. Fill using do-while
        int i = 0;
        int num = 1;
        do {
            arr[i] = (i == 9) ? 0 : num * num;
            num++;
            i++;
        } while (i < 10);

        // b + c: Sum odd numbers, skip even, break at 81
        int j = 0, sum = 0;
        while (j < arr.length) {
            if (arr[j] == 81)
                break;
            if (arr[j] % 2 != 0) {
                sum += arr[j];
            }
            j++;
        }

        System.out.println("Sum of odd numbers before 81: " + sum);
    }
}
